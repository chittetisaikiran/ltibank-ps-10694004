

export class Customer {
     public id?: number;
     public name?: string;
     public age?: number;
     public typeofAccount?: string ;
     public addressId?: number;
     public street?: string;
     public city?: string;
     public state?: string;
     public zipCode?: string;
      
   }
   