import { Injectable } from '@angular/core';
import {HttpClient}  from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http: HttpClient) { }
  getAllCustomer(): Observable<any> {
    return this.http.get(`http://bankapplicationlti-env.eba-7ptihm3u.us-east-2.elasticbeanstalk.com/bank/getCustomer`);
  }

  AddCustomer(customer: Object): Observable<Object> {
    console.log("Service class");
    return this.http.post(`http://bankapplicationlti-env.eba-7ptihm3u.us-east-2.elasticbeanstalk.com/bank/customer/`, customer);
  }

  updateCustomer(id: number, value: any): Observable<any> {
    return this.http.put(`http://bankapplicationlti-env.eba-7ptihm3u.us-east-2.elasticbeanstalk.com/bank/updateCustomer/${id}`, value);
  }

  deleteCustomer(id: number): Observable<any> {
    return this.http.delete(`http://bankapplicationlti-env.eba-7ptihm3u.us-east-2.elasticbeanstalk.com/bank/deleteCustomer/${id}`, { responseType: 'text' });
  }

   getCustomerByID(id: number): Observable<any> {
     return this.http.get(`http://bankapplicationlti-env.eba-7ptihm3u.us-east-2.elasticbeanstalk.com/bank/getCustomer/${id}`);
   }

  
}

