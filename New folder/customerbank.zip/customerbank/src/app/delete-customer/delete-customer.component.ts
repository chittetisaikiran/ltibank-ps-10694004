import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Customer } from 'src/Customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-delete-customer',
  templateUrl: './delete-customer.component.html',
  styleUrls: ['./delete-customer.component.css']
})
export class DeleteCustomerComponent implements OnInit {
  id: number = 0;
  customer:Customer = new Customer();
  
 
   constructor(private route: ActivatedRoute,private router: Router,
     private customerService: CustomerService) { }
 
   ngOnInit() {
     this.customer = new Customer();
 
     this.id = this.route.snapshot.params['id'];
     
     
   }
  //  reloadData() {
  //   this.customer = this.customerService.getAllCustomer();
  // }

  deleteCustomer(id: number) {
    this.customerService.deleteCustomer(id)
      .subscribe(
        data => {
          console.log(data);
        //  this.reloadData();
        },
        error => console.log(error));
  }

 
   onSubmit() {
     this.deleteCustomer(this.id);    
   }
 
   gotoList() {
     this.router.navigate(['/Customers']);
   }

}
